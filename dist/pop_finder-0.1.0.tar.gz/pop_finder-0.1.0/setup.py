# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['pop_finder']

package_data = \
{'': ['*']}

install_requires = \
['argparse>=1.4.0,<2.0.0',
 'h5py==2.10.0',
 'keras-tuner==1.0.2',
 'matplotlib==3.3.2',
 'numpy==1.18.4',
 'pandas>=1.2.3,<2.0.0',
 'scikit-allel==1.3.2',
 'sklearn>=0.0,<0.1',
 'tensorflow==2.3.0',
 'zarr>=2.6.1,<3.0.0']

setup_kwargs = {
    'name': 'pop-finder',
    'version': '0.1.0',
    'description': '"Python package that uses neural networks for population assignment"',
    'long_description': None,
    'author': 'Katie Birchard',
    'author_email': 'birchardkatie@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.7.1,<4.0',
}


setup(**setup_kwargs)
